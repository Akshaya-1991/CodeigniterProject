<?php


class AdminDashboard extends CI_Controller {

	function index()
	{
		if(empty($this->session->userdata['user'])){
			redirect(base_url().'login');
		}
		$this->load->view('admin/dashboard');
	}

	function logout()
	{
		$this->session->unset_userdata('user');
		redirect(base_url().'login');
	}

	function profile($id)
	{
		$data = array();
		$this->load->model('User_model');
		$userinfo = $this->User_model->getUserData($id);

		$data['userinfo'] = $userinfo;
		$this->load->view('admin/profile',$data);
	}
}
