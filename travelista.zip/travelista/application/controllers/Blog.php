<?php

class Blog extends CI_Controller {

	public function __construct()
        {
            parent::__construct();
			$this->load->model('Blog_model');
        }

	function index()
	{
		//$this->load->model('Blog_model');
		$blogs = $this->Blog_model->fetchAllBlogs();
		$data = array();
		$data['blogs'] = $blogs;
		$this->load->view('admin/blog/list', $data);
	}
	function add()
	{
		$this->load->library('form_validation');
		//$this->load->model('Blog_model');

		$this->form_validation->set_rules('blog_title','Title','required|trim');
		$this->form_validation->set_rules('blog_description','Description','required|trim');
		$this->form_validation->set_rules('blog_author','Author','required|trim');
		if (empty($_FILES['blog_image']['name']))
		{
			$this->form_validation->set_rules('blog_image', 'Attach Image', 'required');
		}

		if($this->form_validation->run() == true){
			$config['upload_path'] = 'uploads/';
			$config['allowed_types'] = 'gif|jpg|png|jpeg|JPEG|JPG|PNG|GIF';
			$this->load->library('upload', $config);
			if($this->upload->do_upload('blog_image'))          
			{
				  
				$data_upload_files = $this->upload->data();

				$image = $data_upload_files['file_name'];

				$config['image_library'] = 'gd2';
				$config['source_image'] = './uploads/'.$data_upload_files["file_name"];
				$config['new_image'] = './uploads/thumb/'.$data_upload_files["file_name"];
				$config['maintain_ratio'] = TRUE;
				$config['width']         = 130;
				$config['height']       = 80;

				$this->load->library('image_lib',$config);
				$this->image_lib->initialize($config);
				$this->image_lib->resize();

				$formData = array();
				$formData['title']= $this->input->post('blog_title');
				$formData['description']= $this->input->post('blog_description');
				$formData['author']= $this->input->post('blog_author');
				$formData['image'] = $image;
				$formData['created_at']= date('Y-m-d');

				$this->Blog_model->create($formData);
				$this->session->set_flashdata('success','Blog created succesfully!');
				redirect(base_url().'blog/index');          
			}else{
				echo $this->upload->display_errors();           
			} 
		}else{
			$this->load->view('admin/blog/add');
		}
		
	}

	function edit($id)
	{
		$data = array();
		$this->load->library('form_validation');
		//$this->load->model('Blog_model');
		$blog = $this->Blog_model->fetchBlog($id);

		if(empty($blog)){
			$this->session->set_flashdata('success','Blog not found!');
			redirect(base_url().'blog/index'); 
		}

		$this->form_validation->set_rules('blog_title','Title','required|trim');
		$this->form_validation->set_rules('blog_description','Description','required|trim');
		$this->form_validation->set_rules('blog_author','Author','required|trim');
		
		if($this->form_validation->run() == true){
			if(!empty($_FILES['blog_image']['name']))
			{
				unlink('./uploads/'.$blog['image']);
				unlink('./uploads/thumb/'.$blog['image']);
				$config['upload_path'] = 'uploads/';
				$config['allowed_types'] = 'gif|jpg|png|jpeg|JPEG|JPG|PNG|GIF';
				$this->load->library('upload', $config);
				if($this->upload->do_upload('blog_image'))          
				{ 
					$data_upload_files = $this->upload->data();

					$image = $data_upload_files['file_name'];

					$config['image_library'] = 'gd2';
					$config['source_image'] = './uploads/'.$data_upload_files["file_name"];
					$config['new_image'] = './uploads/thumb/'.$data_upload_files["file_name"];
					$config['maintain_ratio'] = TRUE;
					$config['width']         = 130;
					$config['height']       = 80;

					$this->load->library('image_lib',$config);
					$this->image_lib->initialize($config);
					$this->image_lib->resize();			
				}else{
					echo $this->upload->display_errors();           
				} 
			}else{
				$image = $blog['image'];
			}
			$formData = array();
			$formData['title']= $this->input->post('blog_title');
			$formData['description']= $this->input->post('blog_description');
			$formData['author']= $this->input->post('blog_author');
			$formData['image'] = $image;
			$formData['created_at']= date('Y-m-d');

			$this->Blog_model->updateBlog($id,$formData);
			$this->session->set_flashdata('success','Blog updated succesfully!');
			redirect(base_url().'blog/index');
		}else{
			$data['blog'] = $blog;
			$this->load->view('admin/blog/edit',$data);
		}
	}

	function delete($id)
	{
		//$this->load->model('Blog_model');
		$blog = $this->Blog_model->fetchBlog($id);
		unlink('./uploads/'.$blog['image']);
		unlink('./uploads/thumb/'.$blog['image']);
		if(empty($blog)){
			$this->session->set_flashdata('success','Blog not found!');
			redirect(base_url().'blog/index'); 
		}

		$this->Blog_model->deleteBlog($id);
		$this->session->set_flashdata('success','Blog deleted successfully!');
		redirect(base_url().'blog/index'); 
	}

	 
}
