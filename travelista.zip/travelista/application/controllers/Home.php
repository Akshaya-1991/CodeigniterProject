<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index()
	{
		$data= array();
		$this->load->model('Blog_model');
		$ActiveBlogs = $this->Blog_model->fetchAllActiveBlogs();
		$data['allblogs'] = $ActiveBlogs;
		$this->load->view('home',$data);
	}
}
