<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function index()
	{
		$this->load->library('form_validation');
		$this->load->model('User_model');

		$this->form_validation->set_rules('UserEmail','User Email','required');
		$this->form_validation->set_rules('UserPwd','User Password','required');

		if($this->form_validation->run() == false){
			$this->load->view('admin/login');
		}else{
			$Useremail = $this->input->post('UserEmail');
			$Password = $this->input->post('UserPwd');

			$user = $this->User_model->doLogin($Useremail,$Password);
			
			if(!empty($user))
			{
				$this->session->set_userdata('user',$user);
				redirect(base_url().'adminDashboard');
			}else{
				$this->session->set_flashdata('ErrMsg','Useremail/Password incorrect.');
				redirect(base_url().'login');
			}

		}	
	}
}
