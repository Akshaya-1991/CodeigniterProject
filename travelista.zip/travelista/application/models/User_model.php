<?php 

    class User_model extends CI_model
    {

        function doLogin($useremail,$password)
        {
            $this->db->where('UserEmail',$useremail);
            $this->db->where('Password',$password);

            $query = $this->db->get('users');
            $user = $query->row_array();
            return $user;
        }

        function getUserData($id)
        {
            $this->db->where('ID',$id);
            $query = $this->db->get('users');
            $user = $query->row_array();
            return $user;
        }
    }


?>