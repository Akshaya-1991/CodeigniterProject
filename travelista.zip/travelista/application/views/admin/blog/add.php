<?php 
    $this->load->view('admin/section/header');
?>
    <div class="main-panel">
        <div class="content-wrapper">
            <div class="row">
            <!-- <h1 class="h2">Add Blog</h4> -->
                <!-- Divider -->
                <!-- <hr class="sidebar-divider my-0"> -->
                <div class="col-12 grid-margin stretch-card" style="padding: 10px 50px;">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-title"><h3 style="font-weight:bold;">Add Blog</h3></div>
                            <form name="addBlog" id="addBlog" action="<?php base_url().'blog/add';?>" method="post" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label>Title</label>
                                    <input type="text" name="blog_title" id="blog_title" class="form-control" value="<?php echo set_value('blog_title');?>"> 
                                    <p><?php echo form_error('blog_title');?></p>
                                </div>
                                <div class="form-group">
                                    <label>Description</label>
                                    <textarea type="text" name="blog_description" id="blog_description" class="form-control" rows="5" value="<?php echo set_value('blog_description');?>"></textarea>
                                    <p><?php echo form_error('blog_description');?></p>
                                </div>
                                <div class="form-group">
                                    <label>Author</label>
                                    <input type="text" name="blog_author" id="blog_author" class="form-control" value="<?php echo set_value('blog_author');?>"> 
                                    <p><?php echo form_error('blog_author');?></p>
                                </div>
                                <div class="form-group">
                                    <label>Image</label>
                                    <input type="file" name="blog_image" id="blog_image" class="file-upload-default" value="<?php echo set_value('blog_image');?>">
                                    <p><?php echo form_error('blog_image');?></p>
                                </div>
                                <div class="form-group">
                                    <button class="btn btn-primary">Create</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php 
    $this->load->view('admin/section/footer');
?>