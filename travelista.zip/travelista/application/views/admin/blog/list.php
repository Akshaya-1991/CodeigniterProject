<?php 
    $this->load->view('admin/section/header');
?>
<style rel="stylesheet" type="text/css">
.text{
    max-width: 200px;
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
}
</style>
    <div class="main-panel">
        <div class="content-wrapper">
            <div class="row">
                <div class="col-12 grid-margin stretch-card" style="padding: 10px 50px;">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-title"><h3 style="font-weight:bold;">Blog List</h3></div>
                            <?php $successMsg = $this->session->userdata('success');?>
                            <?php if(!empty($successMsg)){?>
                            <div class="alert alert-success">
                                <?php echo $successMsg;?>
                            </div>
                            <?php }?>
                            <div class="table-responsive">
                                <table id="blogList" class="table table-striped table-bordered" style="width:100%">
                                    <thead>
                                        <tr>
                                        <th>Title</th>
                                        <th>Description</th>
                                        <th>Author</th>
                                        <th>Image</th>
                                        <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php if(!empty($blogs)){
                                            foreach($blogs as $blog){
                                    ?>
                                    <tr>
                                        <td><?php echo $blog['title'];?></td>
                                        <td class="text" title="<?php echo $blog['description'];?>"><?php echo $blog['description'];?></td>
                                        <td><?php echo $blog['author'];?></td>
                                        <td>
                                            <img class="img-fluid img-thumbnail" src="<?php echo base_url().'uploads/thumb/'.$blog['image'];?>" class="img-fluid img-thumbnail" alt="Image">
                                        </td>
                                        <td>
                                             <a href="<?php echo base_url().'blog/edit/'.$blog['blog_id'];?>"><span id="editBlog<?php echo $blog['blog_id'];?>"><i class="fas fa-edit"></i></span></a>   
                                             <a href="#" onclick="deleteBlog(<?php echo $blog['blog_id'];?>);" style="color:red;"><span id="dangerBlog<?php echo $blog['blog_id'];?>"><i class="fas fa-trash-alt"></i></a> 
                                        </td>
                                    </tr>
                                    <?php }
                                        }else{
                                    ?>
                                    <tr><td colspan=6>No blogs to display.</td></tr>
                                    <?php }?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>Title</th>
                                            <th>Description</th>
                                            <th>Author</th>
                                            <th>Image</th>
                                            <th>Action</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php 
    $this->load->view('admin/section/footer');
?>
<script type="text/javascript">
    $(document).ready(function() {
        $('#blogList').DataTable({
            "lengthMenu": [5, 10]
        });
    } );
    function deleteBlog(id){
        if(confirm("Are you sure you want to delete?")){
            window.location.href="<?php echo base_url().'blog/delete/'?>"+id;
        }
    }
    
</script>