<?php 
    $this->load->view('admin/section/header');
?>
    <main role="main" class="col-md-9">
        <h3 class="text-center" style="padding-top:100px;">Dashboard</h3>
        <h4 class="text-center" >Welcome to Myblog Dashboard</h4>
    </main>

<?php 
    $this->load->view('admin/section/footer');
?>