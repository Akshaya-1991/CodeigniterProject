<?php 
    $this->load->view('admin/section/header');
?>
    <div class="main-panel">
        <div class="content-wrapper">
            <div class="row">
            <!-- <h1 class="h2">Add Blog</h4> -->
                <!-- Divider -->
                <!-- <hr class="sidebar-divider my-0"> -->
                <div class="col-12 grid-margin stretch-card" style="padding: 10px 50px;">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-title"><h3 style="font-weight:bold;">Profile</h3></div>
                                <div class="form-group">
                                    <label>ID</label>
                                    <input type="text" name="userId" id="userId" class="form-control" value="<?php echo $userinfo['ID'];?>" disabled> 
                                </div>
                                <div class="form-group">
                                    <label>Name</label>
                                    <input type="text" name="UserName" id="UserName" class="form-control" value="<?php echo $userinfo['UserName'];?>" disabled> 
                                </div>
                                <div class="form-group">
                                    <label>Email</label>
                                    <input type="text" name="UserEmail" id="UserEmail" class="form-control" value="<?php echo $userinfo['UserEmail'];?>" disabled> 
                                </div>
                                <a href="<?php echo base_url().'admin/dashboard';?>" class="btn btn-secondary">Cancel</a> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php 
    $this->load->view('admin/section/footer');
?>